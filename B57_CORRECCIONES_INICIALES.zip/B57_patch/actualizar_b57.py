from pathlib import Path
import shutil,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
required=['index.html','catalog.json','styles.css']
missing=[x for x in required if not (root/x).exists()]
if missing: raise SystemExit('Faltan archivos de B56: '+', '.join(missing))
import json
catalog=json.loads((root/'catalog.json').read_text(encoding='utf-8'))
assert isinstance(catalog,list)
selected={'PA-203','ID-101','MKT-201'}
found={x['code'] for x in catalog}
assert selected<=found, f'No están todos los cursos: {selected-found}'
backup=root/'_respaldo_pre_B57'
backup.mkdir(exist_ok=True)
for name in required:
 if not (backup/name).exists():shutil.copy2(root/name,backup/name)
# Keep the full catalog in backup and limit public courses, preserving lesson structure.
(root/'catalog.json').write_text(json.dumps([x for x in catalog if x['code'] in selected],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'index.html';s=p.read_text(encoding='utf-8')
s=s.replace('20 cursos iniciales con actividades de comprobación.','3 cursos de lanzamiento con actividades de comprobación.')
s=s.replace('20 cursos iniciales','3 cursos de lanzamiento')
s=s.replace('<strong>20</strong><span>Cursos iniciales</span>','<strong>3</strong><span>Cursos de lanzamiento</span>')
# Remove redundant secondary hero section; retain primary photo banner.
start=s.find('<section class="hero pa-b37-hero-actions">')
if start!=-1:
 end=s.find('</section>',start)
 if end!=-1:s=s[:start]+s[end+len('</section>'):]
s=s.replace('styles.css?v=b56-20261010','styles.css?v=b57-visual')
s=s.replace('</head>','<link rel="stylesheet" href="b57-overrides.css?v=1"/>\n</head>',1)
p.write_text(s,encoding='utf-8')
(root/'b57-overrides.css').write_text('''/* B57 visual refinements, without modifying existing functionality */
:root{--b57-gold:#d7b96a}
.pa-b54-hero-content{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,.9fr);align-items:center;gap:clamp(1rem,4vw,3rem)}
.pa-b54-hero-photo{display:block;width:100%;max-height:470px;object-fit:cover;object-position:center;border-radius:18px}
.grid.courses{grid-template-columns:repeat(auto-fit,minmax(min(100%,255px),1fr));gap:clamp(12px,2vw,22px)}
.grid.courses article{min-width:0;overflow:hidden}
.grid.courses img{width:100%;max-width:100%;object-fit:cover;aspect-ratio:16/10}
.section{scroll-margin-top:80px}
@media(max-width:760px){.pa-b54-hero-content{grid-template-columns:1fr}.pa-b54-hero-photo{max-height:300px}.grid.courses{grid-template-columns:1fr}}
''',encoding='utf-8')
print('B57 base visual preparada. Cursos visibles:',', '.join(sorted(selected)))
print('Respaldo original:',backup)
